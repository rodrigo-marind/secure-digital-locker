# StudyApp – Gestión de Grupos de Estudio

Este proyecto es un incremento funcional desarrollado como parte de un Sprint académico para el curso de Metodologías Ágiles de Desarrollo.

##  Objetivo del Incremento
Permitir a los estudiantes universitarios:
- Registrarse en la aplicación
- Iniciar sesión con sus credenciales
- Crear un grupo básico de estudio
- Visualizar los grupos creados
- Recibir sugerencias automáticas de nombre para el grupo (IA mock)

Este incremento cumple el Sprint Goal planteado y entrega valor funcional al usuario final.

##  Equipo Scrum

| Nombre | Rol |
|--------|-----|
| Raheem | Product Owner |
| Ariana | Scrum Master |
| Rodrigo | Dev Team |
| Jousthin | Dev Team |

##  Tecnologías utilizadas
- HTML
- CSS
- JavaScript
- LocalStorage (para persistencia de datos en navegador)

##  Cómo ejecutar el proyecto
1. Descargar todos los archivos del repositorio
2. Guardarlos en una misma carpeta (studyapp)
3. Abrir el archivo **index.html** en un navegador web
4. Probar el flujo completo:
   - Crear usuario → Iniciar sesión → Crear grupo → Ver grupos

##  Funcionalidades desarrolladas en este Sprint
- Interfaz de registro y login
- Validación básica de usuarios
- Creación de grupos por materia
- Listado de grupos creados
- Sugerencias automáticas de nombre (IA simulada con JavaScript)

##  Definición de Hecho (DoD)
- Incremento funcional sin errores críticos
- Datos guardados correctamente en LocalStorage
- Todo visible durante Sprint Review
- Código subido en una estructura clara
- README incluido

##  Futuras iteraciones del producto
- Unirse a grupos creados por otros usuarios
- Chat interno entre miembros del grupo
- Calendario de reuniones y recordatorios
- Autenticación conectada a base de datos real
- IA avanzada para analizar horarios óptimos del grupo

---

Proyecto desarrollado con fines académicos.
