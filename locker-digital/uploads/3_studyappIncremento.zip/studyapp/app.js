// Guardar usuario
const registerForm = document.getElementById("registerForm");
if (registerForm) {
  registerForm.addEventListener("submit", (e) => {
    e.preventDefault();
    let users = JSON.parse(localStorage.getItem("users")) || [];

    const user = {
      name: document.getElementById("name").value,
      email: document.getElementById("email").value,
      password: document.getElementById("password").value,
    };

    users.push(user);
    localStorage.setItem("users", JSON.stringify(users));
    alert("Usuario registrado correctamente");
    window.location = "index.html";
  });
}

// Login
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    let users = JSON.parse(localStorage.getItem("users")) || [];

    const email = document.getElementById("loginEmail").value;
    const password = document.getElementById("loginPassword").value;

    const found = users.find(u => u.email === email && u.password === password);

    if (found) {
      localStorage.setItem("currentUser", JSON.stringify(found));
      window.location = "dashboard.html";
    } else {
      alert("Credenciales incorrectas");
    }
  });
}

// Mostrar nombre de usuario
const currentUser = JSON.parse(localStorage.getItem("currentUser"));
if (currentUser && document.getElementById("userName")) {
  document.getElementById("userName").innerText = currentUser.name;
}

// Logout
function logout() {
  localStorage.removeItem("currentUser");
  window.location = "index.html";
}

// Crear grupo
const groupForm = document.getElementById("groupForm");
if (groupForm) {
  groupForm.addEventListener("submit", (e) => {
    e.preventDefault();
    let groups = JSON.parse(localStorage.getItem("groups")) || [];

    const newGroup = {
      subject: document.getElementById("subject").value,
      groupName: document.getElementById("groupName").value,
      owner: currentUser.email,
    };

    groups.push(newGroup);
    localStorage.setItem("groups", JSON.stringify(groups));
    loadGroups();
  });
}

// Cargar grupos
function loadGroups() {
  const groupList = document.getElementById("groupList");
  if (!groupList) return;
  groupList.innerHTML = "";
  let groups = JSON.parse(localStorage.getItem("groups")) || [];
  groups
    .filter(g => g.owner === currentUser.email)
    .forEach(g => {
      let li = document.createElement("li");
      li.textContent = `${g.groupName} - ${g.subject}`;
      groupList.appendChild(li);
    });
}
loadGroups();

// Mock IA: sugerir nombre
function suggestName() {
  const subject = document.getElementById("subject").value;
  const ideas = ["Experts", "Legends", "Squad", "Crew", "Academy"];
  const random = ideas[Math.floor(Math.random() * ideas.length)];
  document.getElementById("groupName").value = `${subject} ${random}`;
}

function goDashboard() {
  window.location = "dashboard.html";
}

// Borrar todos los grupos del usuario actual
function deleteAllGroups() {
  if (!confirm("¿Seguro que deseas borrar todos tus grupos? Esta acción no se puede deshacer.")) {
    return;
  }

  let groups = JSON.parse(localStorage.getItem("groups")) || [];
  const currentUser = JSON.parse(localStorage.getItem("currentUser"));

  groups = groups.filter(g => g.owner !== currentUser.email);

  localStorage.setItem("groups", JSON.stringify(groups));
  loadGroups(); // Recargar lista actualizada
  alert("Todos los grupos fueron eliminados.");
}

